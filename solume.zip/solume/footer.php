			</div> <!-- /Inside Content -->
			<div class="wrap_footer">
				<?php echo apply_filters( 'solume_render_footer', '' ); ?>
			</div>
			
		</div> <!-- Ova Wrapper -->	
		<?php wp_footer(); ?>
	</body><!-- /body -->
</html>